package com.fis.bankapplicationspringboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.fis.bankapplicationspringboot.model.Logger;

public interface LoggerRepo extends CrudRepository<Logger, Integer> {

}
