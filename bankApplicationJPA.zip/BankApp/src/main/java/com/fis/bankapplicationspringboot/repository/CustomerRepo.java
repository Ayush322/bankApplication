package com.fis.bankapplicationspringboot.repository;

import org.springframework.data.repository.CrudRepository;

import com.fis.bankapplicationspringboot.model.Customer;

public interface CustomerRepo extends CrudRepository<Customer, Integer> {

}
