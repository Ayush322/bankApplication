package com.fis.bankapplicationspringboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplicationspringboot.model.Customer;
import com.fis.bankapplicationspringboot.repository.CustomerRepo;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepo customerRepo;
// this method is used to create the customer
	public void createCustomer(Customer customer) {
		customerRepo.save(customer);
	}
// this method is used to get customer information by account ID
	public Customer getCustomerInfo(int acctID) {
		return customerRepo.findById(acctID).orElse(null);
	}
// this method is used to delete the customer by account ID
	public void deleteCustomer(int acctID) {
		customerRepo.deleteById(acctID);
	}

}
