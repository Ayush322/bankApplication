package com.fis.bankapplicationspringboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplicationspringboot.exception.ErrorResponse;
import com.fis.bankapplicationspringboot.model.Customer;
import com.fis.bankapplicationspringboot.service.CustomerService;
//{
//    "acctID": "239",
//	"custName": "Ayush",
//	"city": "Bangalore",
//	"state": "Karnataka",
//	"country": "India",
//	"phoneNo": "8976532590",
//	"password": "ayush12345"
//}

@RestController
public class CustomerDataController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private AccountDataController accountDataController;

	@PostMapping("/customer")
	public void createCustomer(@RequestBody Customer customer) {
		//call customer service to create the customer
		customerService.createCustomer(customer);
		// call accountController to create an account for the customer with a 0 balance and active status
		accountDataController.createAccount(customer.getAcctID(), 0, "Active");
	}

	@GetMapping("/customer/{acctID}")
// Handling the exception with responseEntity using
		public ResponseEntity<?> getCustomerInfo(@PathVariable int acctID) {
	        Customer user = customerService.getCustomerInfo(acctID);
	        if (user == null) {
	          ErrorResponse errorResponse = new ErrorResponse();
	          errorResponse.setMessage("Record not found");
	          return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	         }
	       return new ResponseEntity<>(user, HttpStatus.OK); 
	    }    
	

	@DeleteMapping("/customer/{acctID}")
	public void deleteCustomer(@PathVariable int acctID) {
		// delete the account details of the customer
		customerService.deleteCustomer(acctID);
	}
	
	

}
