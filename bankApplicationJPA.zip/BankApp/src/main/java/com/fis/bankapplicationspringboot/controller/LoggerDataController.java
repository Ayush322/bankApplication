package com.fis.bankapplicationspringboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplicationspringboot.exception.UserNotFound;
import com.fis.bankapplicationspringboot.model.Logger;
import com.fis.bankapplicationspringboot.service.LoggerService;

@RestController
public class LoggerDataController {
	@Autowired
	private LoggerService loggerService;

	// addLog method definition
	public void addLog(Logger logger) {
		// this method adds a log using the loggerservice
		loggerService.addLog(logger);
	}

	// showLog
	// this method is used to retrieve and return logs based on the account ID
	@GetMapping("/account/{acctID}/logs")
	public Logger showLog(@PathVariable int acctID) throws UserNotFound {
		return loggerService.showLog(acctID);
	}

	public void deleteLog(int acctID) {
		// this method is responsible for deleting logs using loggerservice
		loggerService.deleteLog(acctID);
	}
}
